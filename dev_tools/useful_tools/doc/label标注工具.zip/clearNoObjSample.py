import os

txtPath = "txt"
jpgPath = "jpg"
xmlPath = "xml"
txtFile = os.listdir(txtPath)
jpgFile = os.listdir(jpgPath)


#if os.path.exists(fileName):
#   os.remove(fileName)

for i in range(len(txtFile)):
    fileName = txtPath + '/' + txtFile[i]
    input = open(fileName, 'r')
    num = input.read(1)
    input.close()
    if num == '0':
        os.remove(fileName)
        print fileName
        name = txtFile[i].split('.',1)[0]

        jpgName = jpgPath + '/' + "".join(name) + ".jpg"
        if os.path.exists(jpgName):
            os.remove(jpgName)

        xmlName = xmlPath + '/' + "".join(name) + ".xml"
        if os.path.exists(xmlName):
            os.remove(xmlName)


print "finished!"
